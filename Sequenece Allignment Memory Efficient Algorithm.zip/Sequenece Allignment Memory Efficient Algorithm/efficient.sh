#!/bin/sh
# python3 eff.py input1.txt e_output1.txt
python3 efficient_3.py "$1" "$2"
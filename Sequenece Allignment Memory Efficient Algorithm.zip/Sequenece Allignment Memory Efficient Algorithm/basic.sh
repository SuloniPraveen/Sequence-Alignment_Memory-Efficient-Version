#!/bin/sh
# python3 basic.py input1.txt b_output1.txt
python3 basic_3.py "$1" "$2"